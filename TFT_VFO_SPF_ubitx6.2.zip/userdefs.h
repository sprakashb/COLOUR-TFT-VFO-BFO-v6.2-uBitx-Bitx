// uBitx Si5351 clk0 = BFO2, Clk1 = BFO1 and Clk3 = VFO, In old bitx card it may be different

// The following defines can select either uBitx or bitx 20/40 w/10 or 12 MHz IF
#define ubitx
//#define bitx
//#define IF_12MHZ
//#define IF_10MHZ

// User Modifiable parameters
// If display misbehaves / shows random characters - change this magic number and reload the program
uint8_t magic_no = 03; // used for checking the initialization of eprom or to reinitialize change this no.

// Band Limits and frequencies and their corresponding display on band button
// Gen Coverage GC (was VFO)
volatile uint32_t F_MIN_T[9] = {100000UL,  3500000UL, 7000000UL, 10100000UL, 14000000UL, 18068000UL, 21000000UL, 24890000UL, 28000000UL};
volatile uint32_t  F_MAX_T[9] = {30000000UL,  3800000UL, 7200000UL, 10150000UL, 14350000UL, 18168000UL, 21450000UL, 24990000UL, 29700000UL};
String  B_NAME_T[] = { "GC", "80", "40", "30", "20", "17", "15", "12", "10" };
volatile uint32_t  VFO_T[9] = {1000000UL, 3670000UL, 7100000UL, 10120000UL, 14200000UL, 18105000UL, 21200000UL, 24925000UL, 28500000UL};
// VFO_T contains default frequncies when bands change
//----------------------------------------------------------------------------------
// display step size and radix
uint32_t MAX_STEPS = 7;

String step_sz_txt[] = {"  1", " 10", " 50", "100", "500", " 1k", "10k"};   // How the step size is displayed
uint32_t step_sz[] = {   1,   10,   50,   100,   500,   1000, 10000};   // step size values

// alternate step sizes as suggested by Bob GM4CID  as an example to chose your own in above 2 lines this will effect the freq display higlight
//String step_sz_txt[] = {"10  ", "25  ", "50  ", "250 ", "1k  ", "2k5", " 10k "};
//uint32_t step_sz[] = {    10,    25,     50,     250,   1000,   2500,   10000};

int step_index = 5; // 5 is i1KHz as initially slected step size (6th element in above array counting from 0)
uint32_t radix = step_sz[step_index];  //index so radix = 1000

///------------------ User defined values taken as starting point --- use these to configure different Rigs
bool u_active_PTT_in = true;
bool u_Tx_timeout_mode = false;
uint16_t u_Tx_timeout = 20; // time in sec upto which Tx works continuosly then goes to Rx
uint16_t u_ts_delay = 120;    // delay between touch button to reduce sensitivity to avoid multiple touch,
//sometimes even blocking "delay()" used in functions
int32_t u_Offset_VFO = 0, u_Offset_80m = 0, u_Offset_40m = 0, u_Offset_30m = 0, u_Offset_20m = 0;
int32_t u_Offset_17m = 0, u_Offset_15m = 0, u_Offset_12m = 0, u_Offset_10m = 0; //in mem at 8-11, 12-15, etc...
uint16_t u_SM_min = 100, u_SM_max = 1023 ;
uint32_t u_vfo_A = 7050000L, u_vfo_B = 7130000L, u_vfo_M = 14000000L ; // initial temp values
//--------------------
#ifdef ubitx
uint32_t u_bfo1_USB = 56995000L;
uint32_t u_bfo1_LSB = 32994000L;   // Initial Values of BFO1 for USB or LSB
uint32_t u_bfo2 = 11993900L;  // Fixed 12 MHz BFO2 Farhans 11996500 this value found by test
#endif  // define ubitx
//************* for bitx
#ifdef bitx
#ifdef IF_12MHZ
//bfo = 11997000UL;  // for 12MHz xtal filter as in BITx40 HFSIG
uint32_t u_bfo1_USB = 11997000UL;  // Approx values
uint32_t u_bfo1_LSB = 11999000UL;
uint32_t u_bfo2 = 00L; // no bfo2 in bitx
#endif

#ifdef IF_10MHZ    // eg in our homebrewed Bitx 
//bfo = 9996000UL;  // should be selected based on txcvr
uint32_t bfo_USB = 9994000UL;
uint32_t bfo_LSB = 9996000UL;   // all bfos are tunable and saved on EEPROM
uint32_t u_bfo2 = 00L; // no bfo2 in bitx
#endif
#endif //  define bitx
// *************

uint16_t max_timeout = 60; // Max value of timeout in sec  decided by finals and their cooling

// Where is PTT connected on Arduino
#define PTT_Input     26    // D26 pin of Arduino 

// PTT has two modes
// **** Only Toggle PTT in normal mode / in active_ptt mode PTT remains LOW during Tx
// Normal is Toggle PTT (press briefly to go from Rx to Tx & vice-versa)
bool active_PTT_in = true; // if PTT remains continuously low during QSO make it true else false means "toggle PTT" on active low

//========== button color parameters, user modifiable
#define bg_col BLACK  //BLUE  // display back ground color 
// colors of outlines of buttons
#define tb_ol_col WHITE    //  touch button outline 
#define ds_ol_col YELLOW  // DOuble sided button outline
#define ib_ol_col GREEN  // Info buton Outline
#define nb_ol_col RED // Navigation button outline
// colors for filling the buttons
#define tb_fl_col bg_col
#define tb_actv_fl_col RED // when active eg in SPLIT
#define ds_fl_col bg_col
#define ib_fl_col bg_col
#define nb_fl_col bg_col
//  colors for text inside buttons
#define tb_txt_col WHITE
#define tb_actv_txt_col GREEN  // when touch button is active
#define ds_txt_col WHITE
#define ds_actv_txt_col RED  // when double sided button is active eg in Ptt Time Out
#define ds_actv_txt_col2 GREEN // second active color for band and step etc
#define ib_txt_col ORANGE
#define nb_txt_col RED
#define actv_digit_col  ORANGE  // colour of the active digit in freq display

//=================================

//-----------------------USER SELECTABLE DEFINITIONS---------------------------------------------------------------
//#define debug // when needed

// Various displays
//#define         elegoo923         // Joe's 923elegoo displ
//#define         MCUF0x154  // VU2SPF's test display
//#define         PL0x9341    // VU2SPF's Potential Lab display BUT syst
//#define         VE0x7783    // Ventor Tech display SPB/ubitx
//#define           REJI5408      // Rejimon's display from Robodo detected as 5408 but works as 9320
//#define           IL9325      // Robodo 1/18
//#define     Sa35_9486   // sarmas 3.5 inch
//#define        pl0x2053  // poten lab 0x9341 now shows as 2053??

// Si5351 related
#define   si5351correction 0   // IF THERE IS ANY (check using calibrate program in the etherkit Si5351 library examples)

// pin allocations for ubitx digital interface
#define TX_RX    14
#define CW_TONE  15
#define TX_LPF_A 16
#define TX_LPF_B 17
#define TX_LPF_C 18
#define CW_KEY   19     // 20,21 are SDA/SCL (rev order on ubitx interface board v1.0) so rest pins in sequence on Arduino Mega 

// External encoder for frequency selection is connected on pins defined below.

#define ENCODER_A     67    // Encoder pin A is A13 on Mega
#define ENCODER_B     68    // Encoder pin B is A14 on Mega
#define ENCODER_BTN   41    // push button switch on encoder 


// Mechanical P U S H  B U T T O N S ***** O P T I O N A L S ******************************
// If external buttons are needed in parallel with TFT touch buttons then one can connect required ones as per allocation below.
// One can edit the pin numbers as per our convenience
// pin allocations for OPTIONAL input buttons (User selectable ), one pin of button goes to gnd and the other to following Arduino pin
// There are many unused pins still available for including many leftout functions, needing changes in program.
#define BandSelectUp    30  // band change button moves the band from lower to higher frequency side and rotates through all bands sequentally.(only increment)
#define BandSelectDn    31  // band change button moves the band from higher to lower frequency side and rotates through all bands sequentally.(only decrement)
#define MEMUp           32  // Changing memory channel from 1 to 100 in sequence (increment)
#define MEMDn           33  // Changing memory channel from 100 to 1 in sequence (decrement)

#define SideBandSelect 34  // USB or LSB 
#define SAVE          35  //for saving in memory the current parameters like freq, sideband, bfo's on VFO A/B or selected Memory channels
#define VFO           36  // Selecting A/B/M VFO's
#define STEPUp        37  // Selecting Step Size for incrementing frequency 1Hz to 1 MHz 
#define STEPDn        38  // decrease Step size from 1MHz to 1 Hz 
#define VtoMEM        39  // Copying currently selected VFO into currently defined Memory channel
#define MEMtoV        40  // copy from mem to current VFO
//#define NEXT_SCREEN  41  // go to next screen // dev version spf

#define TxTmOut       42 // Activating Tx Time out 
#define SPLIT         43  // Split mode ON/OFF
#define F3            44
#define F4            45
///---------------------------------------------------------------------------------------------
#define countDiv  0   // the count for dividing the encoder pulses , GM4CID found 7 is good for a 400cpr optical encoder

// How S-meter is connected and maximum range of display, The Smeter is not calibrated and one has to match it with known ones and set parameter below
#define SM_In        A12    // Analog Pin A12 for the S Meter function (66)
#define SM_speed 10    // speed of updating S meter
// to be set by trial

#define PM_In   A11  // Analog Pin A11 for Power meter FWD input (3.1cU)
#define PM_In_Ref A10  // Analog A10 reflected input

uint16_t RefCutoff = 400, SwrCutoff = 2; // reflected signal cutoff value, if more than this then PTT will go off from display_smeter() in displays tab

// Due to variations in xtal freq of 5351, the actual frequency of various VFO/BFO may not be on the dot. By receiving station on a known freq (eg a net) find the difference (offset) and put below
// if there are offsets which are not same on each band the following offsets should help in setting exact frequency

//int32_t Offset_VFO=0, Offset_80m=0, Offset_40m=-1500, Offset_30m=0, Offset_20m=-1700, Offset_17m=0, Offset_15m=0,Offset_12m=0,Offset_10m=0;
// offsets for different bands could be -ve also & to be found by experimentation for each rig

//Radio IDs for different Yaesu radios using new Cat commands of 2 Characters (eg FA..) Uncomment only one from following or add your own

char * Radio_id = "ID0251;"  ;   // Yaesu FT-2000
// char * Radio_id = "ID0670;" ; // Yesu FT 991
